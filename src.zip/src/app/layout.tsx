import './globals.css'
import type { Metadata } from 'next'
import { cn } from '@/lib/utils'
import fonts from '@/defaults/fonts'




export const metadata: Metadata = {
  title: 'Advice Care',
  description: '',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={cn(fonts.jakarta.variable, fonts.inter.variable, fonts.manrope.variable, fonts.montserrat)}>
      <body className='font-jakarta'>{children}</body>
    </html>
  )
}
