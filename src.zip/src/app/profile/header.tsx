import Link from "next/link";
import Image from "next/image";
import {
  BoxIcon,
  ChevronDownIcon,
  ChevronLeftIcon,
} from "@radix-ui/react-icons";

export default function ProfileHeader() {
  return (
    <header className="w-full  expert-header-section h-[390px] px-[80px] pt-10 ">
      <h2 className="text-right font-jakarta text-white text-2xl font-bold ">
        🌤 Good Morning
      </h2>
      <div className="flex justify-between mt-[30px]">
        <div className="flex items-center gap-1">
          <Image
            src="/images/expert-advice.png"
            alt=""
            width={50}
            height={50}
            className="w-[50px] h-auto aspect-square"
          />
          <h2 className="text-[36px] font-bold font-montserrat text-white">
            Advice.
          </h2>
        </div>
        <div className="bg-light100 items-center gap-10 border rounded-[50px] pl-3 py-3 pr-6  flex justify-between">
          <div className="flex gap-4 items-center">
            <Image
              src="/images/elipse.svg"
              alt=""
              width={40}
              height={40}
              className="w-[40px] h-auto aspect-square"
            />
            <p className="text-base text-primary font-bold font-jakarta">
              Hi, Tony
            </p>
          </div>
          <ChevronDownIcon className="text-primary w-6 h-6" />
        </div>
      </div>
      <div className="flex items-start mt-[110px]   gap-10">
        <div className="flex flex-col items-center z-50 min-w-[350px] max-w-[350px]   h-[500px] border-2 border-light200  rounded-2xl bg-white">
          <div className="bg-light300 w-[149px] flex justify-center items-center rounded-full h-auto aspect-square mt-[73px]">
            <div className="bg-gray100 w-[109px] h-auto aspect-square  rounded-full "></div>
          </div>
          <h2 className="mt-5 text-[36px] text-black font-jakarta font-bold">
            Hi,Tony
          </h2>
          <div className="w-full h-1 bg-light100 max-w-[180px] rounded-full mt-[19px]">
            <div className="bg-primary w-[90%] h-full rounded-full  rounded-r-none "></div>
          </div>
          <p className="text-base font-jakarta text-black mt-2">
            Your profile is <span className="text-lightblue">80%</span>{" "}
            completed
          </p>
        </div>
        <div className="z-50">
          <Navigation />
        </div>
      </div>
    </header>
  );
}

function Navigation() {
  return (
    <nav className="bg-light100  flex gap-[43px] shadow-navigation-item justify-between items-center p-3 w-full h-[76px] rounded-[15px] max-w-[962px] mt-[74px] ">
      
      <Link
        rel="stylesheet"
        href="/"
        className=" text-base text-white border-light100  py-4 px-[30px] font-jakarta font-semibold  bg-primary   rounded-[15px]"
      >
        Home
      </Link>
      <Link
        rel="stylesheet"
        href="/"
        className=" text-base text-secondary border-light100  py-4 px-[30px] font-jakarta font-semibold  bg-transparent   rounded-[15px]"
      >
        Profile
      </Link>
      <Link
        rel="stylesheet"
        href="/"
        className=" text-base text-secondary border-light100  py-4 px-[30px] font-jakarta font-semibold  bg-transparent   rounded-[15px]"
      >
        Schedule
      </Link>
      <Link
        rel="stylesheet"
        href="/"
        className=" text-base text-secondary border-light100  py-4 px-[30px] font-jakarta font-semibold  bg-transparent   rounded-[15px]"
      >
        Resume
      </Link>
      <Link
        rel="stylesheet"
        href="/"
        className=" text-base text-secondary border-light100  py-4 px-[30px] font-jakarta font-semibold  bg-transparent   rounded-[15px]"
      >
        Payments
      </Link>
      <Link
        rel="stylesheet"
        href="/"
        className=" text-base text-secondary border-light100  py-4 px-[30px] font-jakarta font-semibold  bg-transparent   rounded-[15px]"
      >
        Reviews
      </Link>
    </nav>
  );
}
