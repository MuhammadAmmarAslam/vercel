import ProfileHeader from "../header";
import { ProfileInput } from "../input";

export default function Page() {
  return (
    <main className="bg-white min-h-screen pb-[100px]  w-full">
      <ProfileHeader />
      <section className="p-[60px] pb-[82px] bg-white max-w-[722px] w-full mt-[112px] ml-[482px] rounded-2xl border-2 border-light200">
        <h2 className="text-[32px] font-jakarta font-bold text-black">
          Payout Method
        </h2>
        <p className="text-black text-base font-bold font-jakarta mt-5">
          All sales will incur a 20% Advice fee.
        </p>
        <div className="mt-10">
            <ProfileInput
            className=""
            type="email"
            placeholder="Stripe Email"
            />

        </div>

      </section>
    </main>
  );
}
