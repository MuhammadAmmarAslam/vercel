import { CameraIcon, CheckIcon } from "@radix-ui/react-icons";
import ProfileHeader from "../header";
import Image from "next/image";
import { ProfileInput } from "../input";

export default function Page() {
  return (
    <main className="bg-white min-h-screen pb-[100px]  w-full">
      <ProfileHeader />
      <section className="p-[60px] pb-[38px] bg-white max-w-[722px] w-full mt-[118px] ml-[520px] rounded-2xl border-2 border-light200">
        <h2 className="text-[32px] font-bold text-black font-jakarta">
          Experts Profile
        </h2>
        <div className="flex gap-5 mt-10">
          <div className="bg-light100 p-[30px] rounded-3xl ">
            <div className="flex flex-col items-center justify-center text-center gap-1 h-[160px] w-[140px]">
              <Image
                src="/images/camera.svg"
                alt=""
                width={40}
                height={40}
                className="w-10 h-auto aspect-square"
              />
              <p className="text-gray700 font-jakarta text-base font-medium ">
                Click to change photo
              </p>
            </div>
          </div>
          <div className="w-full">
            <p className="text-black font-jakarta font-bold">
              Social Media Platform
            </p>
            <ProfileInput
              className="mt-6"
              type="url"
              placeholder="LinkedIn Url"
            />
            <ProfileInput
              className="mt-4"
              type="url"
              placeholder="www.yourweb.com"
            />
          </div>
        </div>
        <div className="mt-[30px]">
          <ProfileInput className="" type="text" placeholder="Full Name" />
          <div className="flex gap-2 mt-4">
            <ProfileInput
              className=""
              type="email"
              placeholder="Enter email address"
            />
            <ProfileInput className="" type="text" placeholder="Location" />
          </div>
        </div>
        <textarea
          className="mt-4 bg-light100 px-[30px] w-full rounded-lg p-[30px] hover:bg-light100 hover:border-none border hover:border-light100 resize-none  border-light100"
          rows={10}
          placeholder="Summary"
        />
        <div className="mt-[120px] flex justify-end">
          <button className="w-[212px] text-base font-bold font-jakarta flex items-center justify-center h-[52px] bg-primary text-white rounded-[50px]">
            Update Profile
          </button>
        </div>
      </section>
    </main>
  );
}
